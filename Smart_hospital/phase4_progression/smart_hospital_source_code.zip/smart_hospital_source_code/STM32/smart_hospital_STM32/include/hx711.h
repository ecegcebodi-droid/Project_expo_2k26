/*
 * hx711.h
 *
 *  Created on: 07-Sept-2026
 *      Author: Raqsh
 */


#ifndef INC_HX711_H_
#define INC_HX711_H_

#include "main.h"

void HX711_Init(void);
uint8_t HX711_IsReady(void);
int32_t HX711_Read(void);
int32_t HX711_ReadAverage(uint8_t samples);

#endif

 /* INC_HX711_H_ */
