/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "hx711.h"
#include <stdio.h>
#include <string.h>
#define EMPTY_SETUP_WEIGHT 0.0f
#define FULL_FLUID_WEIGHT 250.0f

/* =========================================================
   GLOBAL VARIABLES
   ========================================================= */

float fluid_mass_g = 0.0f;

/* Initial fluid amount when a new bottle is started */
float initial_fluid_mass_g = 0.0f;

float previous_fluid_mass_g = 0.0f;
float flow_rate_g_min = 0.0f;
float eta_minutes = -1.0f;
float remaining_percent = 0.0f;

char alert[20] = "NONE";
char message[200];
/* =========================================================
   FSR BED OCCUPANCY
   ========================================================= */

uint32_t fsr_adc_value = 0;
uint8_t bed_occupied = 0;
char bed_status[20] = "BED_VACANT";


uint32_t previous_measurement_time = 0;
uint8_t first_measurement = 1;
ADC_HandleTypeDef hadc;
UART_HandleTypeDef huart1;
UART_HandleTypeDef huart2;


/* =========================================================
   LOAD CELL CALIBRATION
   ========================================================= */

float calibration_factor = 423.88f;
long zero_offset = -78725;


/* =========================================================
   FUNCTION DECLARATIONS
   ========================================================= */

void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_ADC_Init(void);

/* =========================================================
   UART2 SEND STRING
   ========================================================= */

void UART2_SendString(char *str)
{
    HAL_UART_Transmit(&huart2,
                      (uint8_t *)str,
                      strlen(str),
                      HAL_MAX_DELAY);
}


/* =========================================================
   MAIN
   ========================================================= */

int main(void)
{
    HAL_Init();

    SystemClock_Config();

    MX_GPIO_Init();

    MX_USART2_UART_Init();

    MX_USART1_UART_Init();
   MX_ADC_Init();

    HX711_Init();


    /* =====================================================
       MAIN LOOP
       ===================================================== */

    while (1)
    {
        /* =================================================
           VARIABLES FOR 20-READING MOVING WINDOW
           ================================================= */

        static float weight_history[20];
        static uint32_t time_history[20];

        static uint8_t history_count = 0;
        static uint8_t history_index = 0;

        static float filtered_weight = 0.0f;
        static uint8_t filter_initialized = 0;

        static uint32_t last_sample_time = 0;

        int32_t raw_value;
        float weight_g;

        uint32_t current_time;


        /* =================================================
           1. READ HX711
           ================================================= */

        raw_value = HX711_ReadAverage(30);

        weight_g = ((float)raw_value -
                    (float)zero_offset)
                    / calibration_factor;


        /* Prevent negative weight */

        if (weight_g < 0.0f)
        {
            weight_g = 0.0f;
        }


        /* =================================================
           2. FILTER WEIGHT
           ================================================= */

        if (!filter_initialized)
        {
            filtered_weight = weight_g;

            filter_initialized = 1;
        }
        else
        {
            filtered_weight =
                (0.8f * filtered_weight) +
                (0.2f * weight_g);
        }


        /* =================================================
           3. FLUID MASS
           ================================================= */

        fluid_mass_g = filtered_weight;

        if (fluid_mass_g < 0.0f)
        {
            fluid_mass_g = 0.0f;
        }


        /* =================================================
           4. AUTOMATIC INITIAL FLUID DETECTION

           The first stable fluid value becomes 100%.
           Example:

           250 g bottle -> initial = 250 g
           500 g bottle -> initial = 500 g
           750 g bottle -> initial = 750 g
           ================================================= */

        if (initial_fluid_mass_g <= 0.0f &&
            fluid_mass_g > 5.0f)
        {
            initial_fluid_mass_g = fluid_mass_g;
        }


        /* =================================================
           5. TAKE ONE SAMPLE EVERY 10 SECONDS
           ================================================= */

        current_time = HAL_GetTick();

        if ((current_time - last_sample_time) >= 10000 ||
            last_sample_time == 0)
        {
            last_sample_time = current_time;


            /* Store current reading */

            weight_history[history_index] = fluid_mass_g;
            time_history[history_index] = current_time;


            /* Increase number of readings */

            if (history_count < 20)
            {
                history_count++;
            }


            /* Move circular buffer index */

            history_index++;

            if (history_index >= 20)
            {
                history_index = 0;
            }


            /* =================================================
               6. CALCULATE FLOW AFTER 20 READINGS
               ================================================= */

            if (history_count >= 20)
            {
                uint8_t oldest_index;
                uint8_t newest_index;

                float oldest_weight;
                float newest_weight;

                uint32_t oldest_time;
                uint32_t newest_time;

                float elapsed_minutes;
                float fluid_used;
                float new_flow_rate;


                /* Oldest reading */

                oldest_index = history_index;


                /* Newest reading */

                if (history_index == 0)
                {
                    newest_index = 19;
                }
                else
                {
                    newest_index = history_index - 1;
                }


                oldest_weight =
                    weight_history[oldest_index];

                newest_weight =
                    weight_history[newest_index];


                oldest_time =
                    time_history[oldest_index];

                newest_time =
                    time_history[newest_index];


                /* Calculate elapsed time */

                elapsed_minutes =
                    (newest_time - oldest_time)
                    / 60000.0f;


                /* Calculate fluid consumed */

                fluid_used =
                    oldest_weight - newest_weight;


                /* Ignore tiny changes caused by noise */

                if (elapsed_minutes > 0.0f &&
                    fluid_used >= 1.0f)
                {
                    new_flow_rate =
                        fluid_used / elapsed_minutes;


                    /* First valid flow value */

                    if (flow_rate_g_min <= 0.01f)
                    {
                        flow_rate_g_min =
                            new_flow_rate;
                    }
                    else
                    {
                        float maximum_allowed;
                        float minimum_allowed;


                        /* Prevent sudden flow jumps */

                        maximum_allowed =
                            flow_rate_g_min * 1.30f;

                        minimum_allowed =
                            flow_rate_g_min * 0.70f;


                        if (new_flow_rate >
                            maximum_allowed)
                        {
                            new_flow_rate =
                                maximum_allowed;
                        }


                        if (new_flow_rate <
                            minimum_allowed)
                        {
                            new_flow_rate =
                                minimum_allowed;
                        }


                        /* Smooth flow */

                        flow_rate_g_min =
                            (0.8f *
                             flow_rate_g_min) +
                            (0.2f *
                             new_flow_rate);
                    }
                }
            }
        }


        /* =================================================
           7. CALCULATE ETA
           ================================================= */

        if (flow_rate_g_min > 0.01f)
        {
            eta_minutes =
                fluid_mass_g /
                flow_rate_g_min;
        }
        else
        {
            eta_minutes = -1.0f;
        }


        /* If fluid is almost zero */

        if (fluid_mass_g <= 0.5f)
        {
            eta_minutes = 0.0f;
        }


        /* =================================================
           8. CALCULATE REMAINING PERCENTAGE

           IMPORTANT:
           We are NOT using fixed 250 g anymore.

           Initial bottle weight = 100%
           ================================================= */

        if (initial_fluid_mass_g > 0.0f)
        {
            remaining_percent =
                (fluid_mass_g /
                 initial_fluid_mass_g) *
                100.0f;
        }
        else
        {
            remaining_percent = 0.0f;
        }


        /* Limit percentage to 0-100 */

        if (remaining_percent > 100.0f)
        {
            remaining_percent = 100.0f;
        }

        if (remaining_percent < 0.0f)
        {
            remaining_percent = 0.0f;
        }


        /* =================================================
           9. IV ALERT

           >20%       NORMAL
           <=20%      IV_LOW
           <=10%      IV_NEAR_EMPTY
           <=5%       IV_EMPTY
           ================================================= */

        if (remaining_percent <= 5.0f)
        {
            strcpy(alert, "IV_EMPTY");
        }
        else if (remaining_percent <= 15.0f)
        {
            strcpy(alert, "IV_NEAR_EMPTY");
        }
        else if (remaining_percent <= 30.0f)
        {
            strcpy(alert, "IV_LOW");
        }
        else
        {
            strcpy(alert, "NORMAL");
        }

        /* =================================================
           FSR BED OCCUPANCY
           ================================================= */

        /* Start ADC conversion */

        HAL_ADC_Start(&hadc);

        /* Wait for ADC conversion */

        if (HAL_ADC_PollForConversion(&hadc, 100) == HAL_OK)
        {
            /* Read FSR voltage value */

            fsr_adc_value = HAL_ADC_GetValue(&hadc);
        }

        /* Stop ADC */

        HAL_ADC_Stop(&hadc);


        /* =================================================
           BED OCCUPANCY DECISION
           ================================================= */

        /*
           Adjust this threshold after testing.

           Higher ADC value = more pressure
           Lower ADC value = less pressure
        */

        if (fsr_adc_value > 1000)
        {
            bed_occupied = 1;
            strcpy(bed_status, "BED_OCCUPIED");
        }
        else
        {
            bed_occupied = 0;
            strcpy(bed_status, "BED_VACANT");
        }
        /* =================================================
           10. SEND DATA

           UART2 -> Docklight
           UART1 -> ESP32
           ================================================= */

        if (eta_minutes >= 0.0f &&
            flow_rate_g_min > 0.01f)
        {
            sprintf(message,

                    "Fluid=%.2f g | Rate=%.2f g/min | ETA=%.1f min | Remaining=%.1f%% | Alert=%s | FSR=%lu | Bed=%s\r\n",

                    fluid_mass_g,

                    flow_rate_g_min,

                    eta_minutes,

                    remaining_percent,

                    alert,

					fsr_adc_value,

					bed_status);


            /* Send to Docklight */

            UART2_SendString(message);


            /* Send same data to ESP32 */

            HAL_UART_Transmit(&huart1,

                              (uint8_t *)message,

                              strlen(message),

                              HAL_MAX_DELAY);
        }
        else
        {
            sprintf(message,

                    "Fluid=%.2f g | Rate=Waiting | ETA=Waiting | Remaining=%.1f%% | Alert=%s | FSR=%lu | Bed=%s\r\n",

                    fluid_mass_g,

                    remaining_percent,

                    alert,

					fsr_adc_value,

					bed_status);


            /* Send to Docklight */

            UART2_SendString(message);


            /* Send same data to ESP32 */

            HAL_UART_Transmit(&huart1,

                              (uint8_t *)message,

                              strlen(message),

                              HAL_MAX_DELAY);
        }


        /* =================================================
           11. WAIT 1 SECOND
           ================================================= */

        HAL_Delay(1000);
    }


    /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI|RCC_OSCILLATORTYPE_HSI14;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSI14State = RCC_HSI14_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.HSI14CalibrationValue = 16;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART1;
  PeriphClkInit.Usart1ClockSelection = RCC_USART1CLKSOURCE_PCLK1;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC_Init(void)
{

  /* USER CODE BEGIN ADC_Init 0 */

  /* USER CODE END ADC_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC_Init 1 */

  /* USER CODE END ADC_Init 1 */

  /** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
  */
  hadc.Instance = ADC1;
  hadc.Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV1;
  hadc.Init.Resolution = ADC_RESOLUTION_12B;
  hadc.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc.Init.ScanConvMode = ADC_SCAN_DIRECTION_FORWARD;
  hadc.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  hadc.Init.LowPowerAutoWait = DISABLE;
  hadc.Init.LowPowerAutoPowerOff = DISABLE;
  hadc.Init.ContinuousConvMode = DISABLE;
  hadc.Init.DiscontinuousConvMode = DISABLE;
  hadc.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc.Init.DMAContinuousRequests = DISABLE;
  hadc.Init.Overrun = ADC_OVR_DATA_PRESERVED;
  if (HAL_ADC_Init(&hadc) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel to be converted.
  */
  sConfig.Channel = ADC_CHANNEL_0;
  sConfig.Rank = ADC_RANK_CHANNEL_NUMBER;
  sConfig.SamplingTime = ADC_SAMPLETIME_1CYCLE_5;
  if (HAL_ADC_ConfigChannel(&hadc, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC_Init 2 */

  /* USER CODE END ADC_Init 2 */

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{


  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  huart1.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(HX711_SCK_GPIO_Port, HX711_SCK_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : HX711_DOUT_Pin */
  GPIO_InitStruct.Pin = HX711_DOUT_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(HX711_DOUT_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : HX711_SCK_Pin */
  GPIO_InitStruct.Pin = HX711_SCK_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(HX711_SCK_GPIO_Port, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
