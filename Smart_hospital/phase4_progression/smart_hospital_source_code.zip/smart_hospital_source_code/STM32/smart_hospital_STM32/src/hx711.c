#include "hx711.h"




/* Small delay.
 * HX711 only requires the clock pulse to be fast enough.
 */
static void HX711_ShortDelay(void)
{
    for (volatile uint32_t i = 0; i < 20; i++)
    {
        __NOP();
    }
}


void HX711_Init(void)
{
    HAL_GPIO_WritePin(HX711_SCK_GPIO_Port,
                      HX711_SCK_Pin,
                      GPIO_PIN_RESET);
}


uint8_t HX711_IsReady(void)
{
    return (HAL_GPIO_ReadPin(HX711_DOUT_GPIO_Port,
                             HX711_DOUT_Pin) == GPIO_PIN_RESET);
}


int32_t HX711_Read(void)
{
    uint32_t data = 0;

    /* Wait until HX711 has completed conversion */
    uint32_t timeout = HAL_GetTick();

    while (!HX711_IsReady())
    {
        if ((HAL_GetTick() - timeout) > 1000)
        {
            return 0;
        }
    }

    /* Read 24 bits */
    for (uint8_t i = 0; i < 24; i++)
    {
        HAL_GPIO_WritePin(HX711_SCK_GPIO_Port,
                          HX711_SCK_Pin,
                          GPIO_PIN_SET);

        HX711_ShortDelay();

        data = data << 1;

        if (HAL_GPIO_ReadPin(HX711_DOUT_GPIO_Port,
                             HX711_DOUT_Pin) == GPIO_PIN_SET)
        {
            data++;
        }

        HAL_GPIO_WritePin(HX711_SCK_GPIO_Port,
                          HX711_SCK_Pin,
                          GPIO_PIN_RESET);

        HX711_ShortDelay();
    }

    /*
     * 25th pulse:
     * Select Channel A, gain 128
     */
    HAL_GPIO_WritePin(HX711_SCK_GPIO_Port,
                      HX711_SCK_Pin,
                      GPIO_PIN_SET);

    HX711_ShortDelay();

    HAL_GPIO_WritePin(HX711_SCK_GPIO_Port,
                      HX711_SCK_Pin,
                      GPIO_PIN_RESET);

    HX711_ShortDelay();


    /* Convert 24-bit two's complement to signed 32-bit */
    if (data & 0x800000)
    {
        data |= 0xFF000000;
    }

    return (int32_t)data;
}


int32_t HX711_ReadAverage(uint8_t samples)
{
    int64_t sum = 0;

    for (uint8_t i = 0; i < samples; i++)
    {
        sum += HX711_Read();
        HAL_Delay(10);
    }

    return (int32_t)(sum / samples);
}
