#define BLYNK_TEMPLATE_ID "TMPL3m-RgbN3K"
#define BLYNK_TEMPLATE_NAME "Expo"
#define BLYNK_AUTH_TOKEN "Q9gmIivIvgqvNlEtLUQC_ovRXdb7Hhyl"

#define BLYNK_PRINT Serial

#include <WiFi.h>
#include <BlynkSimpleEsp32.h>

/* =========================================================
   WIFI
   ========================================================= */

char ssid[] = "GalaxyA15";
char pass[] = "maara1915";
// =====================================================
// STM32 UART
// ESP32 GPIO16 = RX
// ESP32 GPIO17 = TX
// =====================================================

#define RXD2 16
#define TXD2 17

HardwareSerial STM32Serial(2);

// =====================================================
// BED 1 DATAPINS
// =====================================================

#define V_BED1_IV          V0
#define V_BED1_STATUS      V1
#define V_BED1_ETA         V4
#define V_BED1_FLOW        V10
#define V_BED1_REMAINING   V12

// =====================================================
// BED 2 DATAPINS
// =====================================================

#define V_BED2_STATUS      V2
#define V_BED2_IV          V3
#define V_BED2_ETA         V5
#define V_BED2_FLOW        V11
#define V_BED2_REMAINING   V13

// =====================================================
// ALERT SLOT 1
// =====================================================

#define V_ALERT1           V18
#define V_ETA1             V20
#define V_ACK1             V21
#define V_SOLVE1           V22

// =====================================================
// ALERT SLOT 2
// =====================================================

#define V_ALERT2           V23
#define V_ETA2             V25
#define V_ACK2             V26
#define V_SOLVE2           V27

// =====================================================
// ALERT SLOT 3
// =====================================================

#define V_ALERT3           V33
#define V_ETA3             V34
#define V_ACK3             V35
#define V_SOLVE3           V36

// =====================================================
// ALERT SLOT 4
// =====================================================

#define V_ALERT4           V37
#define V_ETA4             V38
#define V_ACK4             V39
#define V_SOLVE4           V40

// =====================================================
// ADMISSION
// =====================================================

#define V_BED1_ADMISSION       V29
#define V_BED2_ADMISSION       V32

// =====================================================
// NURSE ASSISTED EXIT
// =====================================================

#define V_BED1_ASSISTED_EXIT   V30
#define V_BED2_ASSISTED_EXIT   V31

// =====================================================
// ALERT HISTORY
// =====================================================

#define V_ALERT_HISTORY        V41

#define MAX_HISTORY 10

String alertHistory[MAX_HISTORY];
int historyCount = 0;

// =====================================================
// ALERT TYPES
// =====================================================

enum AlertType
{
  ALERT_NONE,
  ALERT_IV_EMPTY,
  ALERT_BED_VACANT,
  ALERT_IV_NEAR_EMPTY,
  ALERT_IV_LOW
};

// =====================================================
// ALERT STRUCTURE
// =====================================================

struct AlertItem
{
  bool active;
  int bed;
  AlertType type;
  unsigned long createdTime;
  bool acknowledged;
};

#define MAX_ALERTS 4

AlertItem alerts[MAX_ALERTS];

// =====================================================
// BED STATES
// =====================================================

bool bed1Admitted = false;
bool bed2Admitted = false;

bool bed1NurseAssisted = false;
bool bed2NurseAssisted = false;

// =====================================================
// ADMISSION PROTECTION
//
// After admission, old STM32 data is NOT processed.
// The NEXT new STM32 reading becomes eligible.
// =====================================================

bool bed1WaitForNewReading = false;

// =====================================================
// BED 1 DATA
// =====================================================

String bed1Fluid = "0.0";
String bed1Flow = "Waiting";
String bed1ETA = "Waiting";
String bed1Remaining = "0.0";

String bed1Alert = "NORMAL";
String bed1Status = "BED_OCCUPIED";

bool bed1ReadingReceived = false;

// =====================================================
// BED 2 DEMO DATA
// =====================================================

const float BED2_IV = 250.0;
const float BED2_FLOW = 5.0;
const float BED2_REMAINING = 45.0;
const float BED2_ETA = 15.0;

String bed2Status = "BED_OCCUPIED";

// =====================================================
// SOLVED LATCHES
// =====================================================

bool bed1IVSolvedLatch = false;
bool bed1VacantSolvedLatch = false;

bool bed2IVSolvedLatch = false;
bool bed2VacantSolvedLatch = false;

// =====================================================
// WIDGET HIDDEN STATES
//
// false initially is intentional.
// This forces ESP32 to send the first HIDE command.
// =====================================================

bool alertHidden[4] = {
  false,
  false,
  false,
  false
};

bool etaHidden[4] = {
  false,
  false,
  false,
  false
};

bool ackHidden[4] = {
  false,
  false,
  false,
  false
};

bool solveHidden[4] = {
  false,
  false,
  false,
  false
};

// =====================================================
// ALERT PIN ARRAYS
// =====================================================

int alertPins[4] =
{
  V_ALERT1,
  V_ALERT2,
  V_ALERT3,
  V_ALERT4
};

int etaPins[4] =
{
  V_ETA1,
  V_ETA2,
  V_ETA3,
  V_ETA4
};

int ackPins[4] =
{
  V_ACK1,
  V_ACK2,
  V_ACK3,
  V_ACK4
};

int solvePins[4] =
{
  V_SOLVE1,
  V_SOLVE2,
  V_SOLVE3,
  V_SOLVE4
};

// =====================================================
// SET WIDGET HIDDEN
// =====================================================

void setWidgetHidden(
  int pin,
  bool hidden,
  bool &lastState)
{
  if (lastState == hidden)
    return;

  Blynk.setProperty(
    pin,
    "isHidden",
    hidden ? "true" : "false"
  );

  lastState = hidden;
}

// =====================================================
// CLEAR ONE ALERT SLOT
//
// This completely hides:
// Alert
// ETA
// ACK
// SOLVE
// =====================================================

void clearAlertSlot(int slot)
{
  if (slot < 0 || slot >= 4)
    return;

  Blynk.virtualWrite(
    alertPins[slot],
    ""
  );

  Blynk.virtualWrite(
    etaPins[slot],
    ""
  );

  Blynk.virtualWrite(
    ackPins[slot],
    0
  );

  Blynk.virtualWrite(
    solvePins[slot],
    0
  );

  setWidgetHidden(
    alertPins[slot],
    true,
    alertHidden[slot]
  );

  setWidgetHidden(
    etaPins[slot],
    true,
    etaHidden[slot]
  );

  setWidgetHidden(
    ackPins[slot],
    true,
    ackHidden[slot]
  );

  setWidgetHidden(
    solvePins[slot],
    true,
    solveHidden[slot]
  );
}

// =====================================================
// CLEAR ALL ALERT WIDGETS
// =====================================================

void clearAllAlertWidgets()
{
  for (int i = 0; i < 4; i++)
  {
    clearAlertSlot(i);
  }
}

// =====================================================
// ALERT NAME
// =====================================================

String getAlertName(AlertType type)
{
  switch (type)
  {
    case ALERT_IV_EMPTY:
      return "IV EMPTY";

    case ALERT_BED_VACANT:
      return "BED EXIT";

    case ALERT_IV_NEAR_EMPTY:
      return "IV NEAR EMPTY";

    case ALERT_IV_LOW:
      return "IV LOW";

    default:
      return "";
  }
}

// =====================================================
// ALERT PRIORITY
//
// 1 = highest priority
// =====================================================

int getAlertPriority(AlertType type)
{
  switch (type)
  {
    case ALERT_IV_EMPTY:
      return 1;

    case ALERT_BED_VACANT:
      return 2;

    case ALERT_IV_NEAR_EMPTY:
      return 3;

    case ALERT_IV_LOW:
      return 4;

    default:
      return 99;
  }
}

// =====================================================
// ALERT TEXT
//
// No INFO widget.
// Bed number is directly inside alert widget.
// =====================================================

String getAlertText(const AlertItem &item)
{
  String text = "BED ";

  if (item.bed < 10)
    text += "0";

  text += String(item.bed);
  text += " | ";
  text += getAlertName(item.type);

  return text;
}

// =====================================================
// ETA TEXT
//
// BED EXIT = NO ETA
// IV ALERT = ETA
// =====================================================

String getAlertETAText(const AlertItem &item)
{
  if (item.type == ALERT_BED_VACANT)
  {
    return "";
  }

  if (item.bed == 1)
  {
    return "Time remaining = " + bed1ETA;
  }

  if (item.bed == 2)
  {
    return "Time remaining = " +
           String(BED2_ETA, 1) +
           " min";
  }

  return "";
}

// =====================================================
// FIND ALERT
// =====================================================

int findAlert(
  int bed,
  AlertType type)
{
  for (int i = 0; i < MAX_ALERTS; i++)
  {
    if (alerts[i].active &&
        alerts[i].bed == bed &&
        alerts[i].type == type)
    {
      return i;
    }
  }

  return -1;
}

// =====================================================
// FIND BED IV ALERT
// =====================================================

int findBedIVAlert(int bed)
{
  for (int i = 0; i < MAX_ALERTS; i++)
  {
    if (alerts[i].active &&
        alerts[i].bed == bed &&
        (
          alerts[i].type == ALERT_IV_EMPTY ||
          alerts[i].type == ALERT_IV_NEAR_EMPTY ||
          alerts[i].type == ALERT_IV_LOW
        ))
    {
      return i;
    }
  }

  return -1;
}

// =====================================================
// ADD ALERT
// =====================================================

void addAlert(
  int bed,
  AlertType type)
{
  if (type == ALERT_NONE)
    return;

  // ---------------------------------------------
  // Bed 1 protection
  // ---------------------------------------------

  if (bed == 1)
  {
    if (!bed1Admitted)
      return;

    if (type == ALERT_BED_VACANT &&
        bed1NurseAssisted)
      return;
  }

  // ---------------------------------------------
  // Bed 2 protection
  // ---------------------------------------------

  if (bed == 2)
  {
    if (!bed2Admitted)
      return;

    if (type == ALERT_BED_VACANT &&
        bed2NurseAssisted)
      return;
  }

  // ---------------------------------------------
  // Don't create duplicate alert
  // ---------------------------------------------

  if (findAlert(bed, type) >= 0)
    return;

  // ---------------------------------------------
  // Find empty alert slot
  // ---------------------------------------------

  for (int i = 0; i < MAX_ALERTS; i++)
  {
    if (!alerts[i].active)
    {
      alerts[i].active = true;
      alerts[i].bed = bed;
      alerts[i].type = type;
      alerts[i].createdTime = millis();

      // New alert always starts unacknowledged
      alerts[i].acknowledged = false;

      return;
    }
  }
}

// =====================================================
// REMOVE ALERT
// =====================================================

void removeAlert(
  int bed,
  AlertType type)
{
  for (int i = 0; i < MAX_ALERTS; i++)
  {
    if (alerts[i].active &&
        alerts[i].bed == bed &&
        alerts[i].type == type)
    {
      alerts[i].active = false;
      alerts[i].bed = 0;
      alerts[i].type = ALERT_NONE;
      alerts[i].createdTime = 0;
      alerts[i].acknowledged = false;
    }
  }
}

// =====================================================
// REMOVE ALL ALERTS FOR ONE BED
// =====================================================

void removeAllBedAlerts(int bed)
{
  for (int i = 0; i < MAX_ALERTS; i++)
  {
    if (alerts[i].active &&
        alerts[i].bed == bed)
    {
      alerts[i].active = false;
      alerts[i].bed = 0;
      alerts[i].type = ALERT_NONE;
      alerts[i].createdTime = 0;
      alerts[i].acknowledged = false;
    }
  }
}

// =====================================================
// FIND NEXT ALERT BY PRIORITY
//
// Priority:
// IV EMPTY
// BED EXIT
// IV NEAR EMPTY
// IV LOW
//
// Same priority = older first
// =====================================================

int getNextAlertIndex(bool used[])
{
  int best = -1;

  for (int i = 0; i < MAX_ALERTS; i++)
  {
    if (!alerts[i].active)
      continue;

    if (used[i])
      continue;

    if (best == -1)
    {
      best = i;
      continue;
    }

    int currentPriority =
      getAlertPriority(alerts[i].type);

    int bestPriority =
      getAlertPriority(alerts[best].type);

    if (currentPriority < bestPriority)
    {
      best = i;
    }
    else if (currentPriority == bestPriority)
    {
      if (alerts[i].createdTime <
          alerts[best].createdTime)
      {
        best = i;
      }
    }
  }

  return best;
}

// =====================================================
// REFRESH FOUR ALERT SLOTS
//
// IMPORTANT:
// Only existing alerts are shown.
// Empty slots are completely hidden.
// =====================================================

void refreshAlerts()
{
  bool used[MAX_ALERTS] =
  {
    false,
    false,
    false,
    false
  };

  for (int slot = 0; slot < 4; slot++)
  {
    int index =
      getNextAlertIndex(used);

    // =============================================
    // NO ALERT
    // =============================================

    if (index < 0)
    {
      clearAlertSlot(slot);
      continue;
    }

    used[index] = true;

    // =============================================
    // ALERT WIDGET
    // =============================================

    Blynk.virtualWrite(
      alertPins[slot],
      getAlertText(alerts[index])
    );

    setWidgetHidden(
      alertPins[slot],
      false,
      alertHidden[slot]
    );

    // =============================================
    // ETA WIDGET
    // =============================================

    if (alerts[index].type ==
        ALERT_BED_VACANT)
    {
      Blynk.virtualWrite(
        etaPins[slot],
        ""
      );

      setWidgetHidden(
        etaPins[slot],
        true,
        etaHidden[slot]
      );
    }
    else
    {
      Blynk.virtualWrite(
        etaPins[slot],
        getAlertETAText(alerts[index])
      );

      setWidgetHidden(
        etaPins[slot],
        false,
        etaHidden[slot]
      );
    }

    // =============================================
    // ACKNOWLEDGE
    // =============================================

    if (alerts[index].acknowledged)
    {
      // ACK already pressed
      Blynk.virtualWrite(
        ackPins[slot],
        0
      );

      setWidgetHidden(
        ackPins[slot],
        true,
        ackHidden[slot]
      );
    }
    else
    {
      // ACK not pressed
      Blynk.virtualWrite(
        ackPins[slot],
        0
      );

      setWidgetHidden(
        ackPins[slot],
        false,
        ackHidden[slot]
      );
    }

    // =============================================
    // SOLVE
    // =============================================

    if (alerts[index].acknowledged)
    {
      // ACK completed
      // SOLVE appears

      Blynk.virtualWrite(
        solvePins[slot],
        0
      );

      setWidgetHidden(
        solvePins[slot],
        false,
        solveHidden[slot]
      );
    }
    else
    {
      // ACK not completed
      // SOLVE remains hidden

      Blynk.virtualWrite(
        solvePins[slot],
        0
      );

      setWidgetHidden(
        solvePins[slot],
        true,
        solveHidden[slot]
      );
    }
  }
}

// =====================================================
// ADD SOLVED ALERT TO HISTORY
// =====================================================

void addAlertToHistory(
  int bed,
  AlertType type)
{
  if (type == ALERT_NONE)
    return;

  String entry = "BED ";

  if (bed < 10)
    entry += "0";

  entry += String(bed);
  entry += " | ";
  entry += getAlertName(type);
  entry += " | SOLVED";

  // =============================================
  // If history full, remove oldest
  // =============================================

  if (historyCount >= MAX_HISTORY)
  {
    for (int i = 0;
         i < MAX_HISTORY - 1;
         i++)
    {
      alertHistory[i] =
        alertHistory[i + 1];
    }

    historyCount =
      MAX_HISTORY - 1;
  }

  // =============================================
  // Add newest entry
  // =============================================

  alertHistory[historyCount] =
    entry;

  historyCount++;

  // =============================================
  // Build multiline history
  // =============================================

  String historyText = "";

for (int i = historyCount - 1;
     i >= 0;
     i--)
{
  historyText +=
    alertHistory[i];

  historyText +=
    "\r\n\r\n\r\n";
}

  Blynk.virtualWrite(
    V_ALERT_HISTORY,
    historyText
  );
}

// =====================================================
// ACKNOWLEDGE ONE ALERT SLOT
// =====================================================

void acknowledgeAlertSlot(int slot)
{
  if (slot < 0 || slot >= 4)
    return;

  bool used[MAX_ALERTS] =
  {
    false,
    false,
    false,
    false
  };

  // Find the alert currently displayed
  // in this particular slot.

  for (int s = 0; s < slot; s++)
  {
    int previous =
      getNextAlertIndex(used);

    if (previous >= 0)
      used[previous] = true;
  }

  int index =
    getNextAlertIndex(used);

  if (index < 0)
    return;

  // Mark exact alert as acknowledged
  alerts[index].acknowledged = true;

  refreshAlerts();
}

// =====================================================
// SOLVE ONE ALERT SLOT
// =====================================================

void solveAlertSlot(int slot)
{
  if (slot < 0 || slot >= 4)
    return;

  bool used[MAX_ALERTS] =
  {
    false,
    false,
    false,
    false
  };

  int selected[MAX_ALERTS];

  for (int i = 0; i < 4; i++)
  {
    selected[i] =
      getNextAlertIndex(used);

    if (selected[i] >= 0)
    {
      used[selected[i]] = true;
    }
  }

  int alertIndex =
    selected[slot];

  if (alertIndex < 0)
    return;

  // ---------------------------------------------
  // SOLVE only after ACK
  // ---------------------------------------------

  if (!alerts[alertIndex].acknowledged)
  {
    return;
  }

  int bed =
    alerts[alertIndex].bed;

  AlertType type =
    alerts[alertIndex].type;

  // ---------------------------------------------
  // Store in history
  // ---------------------------------------------

  addAlertToHistory(
    bed,
    type
  );

  // ---------------------------------------------
  // Set solved latch
  // ---------------------------------------------

  if (bed == 1)
  {
    if (type == ALERT_BED_VACANT)
    {
      bed1VacantSolvedLatch = true;
    }

    if (type == ALERT_IV_EMPTY ||
        type == ALERT_IV_NEAR_EMPTY ||
        type == ALERT_IV_LOW)
    {
      bed1IVSolvedLatch = true;
    }
  }

  if (bed == 2)
  {
    if (type == ALERT_BED_VACANT)
    {
      bed2VacantSolvedLatch = true;
    }

    if (type == ALERT_IV_EMPTY ||
        type == ALERT_IV_NEAR_EMPTY ||
        type == ALERT_IV_LOW)
    {
      bed2IVSolvedLatch = true;
    }
  }

  // ---------------------------------------------
  // Remove solved alert
  // ---------------------------------------------

  alerts[alertIndex].active = false;
  alerts[alertIndex].bed = 0;
  alerts[alertIndex].type = ALERT_NONE;
  alerts[alertIndex].createdTime = 0;
  alerts[alertIndex].acknowledged = false;

  // ---------------------------------------------
  // Immediately refresh dashboard
  // ---------------------------------------------

  refreshAlerts();
}

// =====================================================
// BED 1 ALERT PROCESSING
// =====================================================

void processBed1Alerts()
{
  if (!bed1Admitted)
    return;

  // =============================================
  // BED EXIT
  // =============================================

  bool bedVacant =
    (bed1Status == "BED_VACANT");

  if (bedVacant)
  {
    // Nurse Assisted Exit completely suppresses
    // BED EXIT alert.

    if (!bed1NurseAssisted &&
        !bed1VacantSolvedLatch)
    {
      addAlert(
        1,
        ALERT_BED_VACANT
      );
    }
  }
  else
  {
    // Bed occupied
    // Remove BED EXIT

    removeAlert(
      1,
      ALERT_BED_VACANT
    );

    // Condition is normal again.
    bed1VacantSolvedLatch = false;
  }

  // =============================================
  // IV ALERT
  // =============================================

  AlertType newIVAlert =
    ALERT_NONE;

  if (bed1Alert == "IV_EMPTY")
  {
    newIVAlert =
      ALERT_IV_EMPTY;
  }
  else if (bed1Alert == "IV_NEAR_EMPTY")
  {
    newIVAlert =
      ALERT_IV_NEAR_EMPTY;
  }
  else if (bed1Alert == "IV_LOW")
  {
    newIVAlert =
      ALERT_IV_LOW;
  }

  // =============================================
  // IV NORMAL
  // =============================================

  if (newIVAlert == ALERT_NONE)
  {
    int existing =
      findBedIVAlert(1);

    if (existing >= 0)
    {
      alerts[existing].active = false;
      alerts[existing].bed = 0;
      alerts[existing].type = ALERT_NONE;
      alerts[existing].createdTime = 0;
      alerts[existing].acknowledged = false;
    }

    // Allow future IV alert
    bed1IVSolvedLatch = false;
  }

  // =============================================
  // IV ABNORMAL
  // =============================================

  else
  {
    if (!bed1IVSolvedLatch)
    {
      int existing =
        findBedIVAlert(1);

      if (existing < 0)
      {
        addAlert(
          1,
          newIVAlert
        );
      }
      else
      {
        // Update alert type if severity changes
        if (alerts[existing].type !=
            newIVAlert)
        {
          alerts[existing].type =
            newIVAlert;

          alerts[existing].createdTime =
            millis();

          // New severity alert needs ACK again
          alerts[existing].acknowledged =
            false;
        }
      }
    }
  }
}

// =====================================================
// BED 2 DEMO PROCESSING
// =====================================================

void processBed2Alerts()
{
  if (!bed2Admitted)
    return;

  // =============================================
  // Fixed Bed 2 demo data
  // =============================================

  bed2Status =
    "BED_OCCUPIED";

  Blynk.virtualWrite(
    V_BED2_STATUS,
    bed2Status
  );

  Blynk.virtualWrite(
    V_BED2_IV,
    BED2_IV
  );

  Blynk.virtualWrite(
    V_BED2_FLOW,
    BED2_FLOW
  );

  Blynk.virtualWrite(
    V_BED2_REMAINING,
    BED2_REMAINING
  );

  Blynk.virtualWrite(
    V_BED2_ETA,
    String(BED2_ETA, 1) +
    " min"
  );

  // =============================================
  // Fixed Bed 2 IV LOW
  // =============================================

  if (!bed2IVSolvedLatch)
  {
    int existing =
      findBedIVAlert(2);

    if (existing < 0)
    {
      addAlert(
        2,
        ALERT_IV_LOW
      );
    }
  }
}

// =====================================================
// PARSE STM32 UART LINE
// =====================================================

void parseSTM32Line(String line)
{
  line.trim();

  if (line.length() == 0)
    return;

  // =============================================
  // Fluid
  // =============================================

  int pos =
    line.indexOf("Fluid=");

  if (pos >= 0)
  {
    int start =
      pos + 6;

    int end =
      line.indexOf(" g", start);

    if (end > start)
    {
      bed1Fluid =
        line.substring(
          start,
          end
        );

      Blynk.virtualWrite(
        V_BED1_IV,
        bed1Fluid.toFloat()
      );
    }
  }

  // =============================================
  // Rate
  // =============================================

  pos =
    line.indexOf("Rate=");

  if (pos >= 0)
  {
    int start =
      pos + 5;

    int end =
      line.indexOf(
        "|",
        start
      );

    if (end < 0)
      end = line.length();

    bed1Flow =
      line.substring(
        start,
        end
      );

    bed1Flow.trim();

    Blynk.virtualWrite(
      V_BED1_FLOW,
      bed1Flow
    );
  }

  // =============================================
  // ETA
  // =============================================

  pos =
    line.indexOf("ETA=");

  if (pos >= 0)
  {
    int start =
      pos + 4;

    int end =
      line.indexOf(
        " min",
        start
      );

    if (end > start)
    {
      bed1ETA =
        line.substring(
          start,
          end
        );

      Blynk.virtualWrite(
        V_BED1_ETA,
        bed1ETA + " min"
      );
    }
    else
    {
      int pipe =
        line.indexOf(
          "|",
          start
        );

      if (pipe < 0)
        pipe = line.length();

      bed1ETA =
        line.substring(
          start,
          pipe
        );

      bed1ETA.trim();

      Blynk.virtualWrite(
        V_BED1_ETA,
        bed1ETA
      );
    }
  }

  // =============================================
  // Remaining
  // =============================================

  pos =
    line.indexOf("Remaining=");

  if (pos >= 0)
  {
    int start =
      pos + 10;

    int end =
      line.indexOf(
        "%",
        start
      );

    if (end > start)
    {
      bed1Remaining =
        line.substring(
          start,
          end
        );

      Blynk.virtualWrite(
        V_BED1_REMAINING,
        bed1Remaining.toFloat()
      );
    }
  }

  // =============================================
  // Alert
  // =============================================

  pos =
    line.indexOf("Alert=");

  if (pos >= 0)
  {
    int start =
      pos + 6;

    int end =
      line.indexOf(
        "|",
        start
      );

    if (end < 0)
      end = line.length();

    bed1Alert =
      line.substring(
        start,
        end
      );

    bed1Alert.trim();
  }

  // =============================================
  // Bed status
  // =============================================

  pos =
    line.indexOf("Bed=");

  if (pos >= 0)
  {
    int start =
      pos + 4;

    int end =
      line.length();

    bed1Status =
      line.substring(
        start,
        end
      );

    bed1Status.trim();

    Blynk.virtualWrite(
      V_BED1_STATUS,
      bed1Status
    );
  }

  // =============================================
  // A NEW STM32 READING HAS ARRIVED
  // =============================================

  bed1ReadingReceived = true;

  // =============================================
  // FIRST NEW READING AFTER ADMISSION
  // =============================================

  if (bed1Admitted &&
      bed1WaitForNewReading)
  {
    bed1WaitForNewReading =
      false;

    processBed1Alerts();
  }
  else if (bed1Admitted)
  {
    processBed1Alerts();
  }

  // =============================================
  // Refresh dashboard
  // =============================================

  refreshAlerts();
}

// =====================================================
// READ STM32 UART
// =====================================================

void readSTM32()
{
  static String line = "";

  while (STM32Serial.available())
  {
    char c = STM32Serial.read();

    if (c == '\n')
    {
      // Print received STM32 reading to ESP32 Serial Monitor
      Serial.println("STM32 DATA:");
      Serial.println(line);
      Serial.println("------------------------------");

      parseSTM32Line(line);

      line = "";
    }
    else if (c != '\r')
    {
      line += c;

      if (line.length() > 300)
      {
        line = "";
      }
    }
  }
}

// =====================================================
// BED 1 ADMISSION
// V29
// =====================================================

BLYNK_WRITE(V_BED1_ADMISSION)
{
  int value =
    param.asInt();

  if (value == 1)
  {
    bed1Admitted = true;

    // IMPORTANT:
    // Do not process old reading.
    // Wait for the next STM32 line.
    bed1WaitForNewReading = true;

    // Clear previous Bed 1 alerts
    removeAllBedAlerts(1);

    bed1IVSolvedLatch = false;
    bed1VacantSolvedLatch = false;

    // Keep switch ON
    Blynk.virtualWrite(
      V_BED1_ADMISSION,
      1
    );

    refreshAlerts();
  }
  else
  {
    bed1Admitted = false;

    bed1WaitForNewReading = false;

    removeAllBedAlerts(1);

    bed1IVSolvedLatch = false;
    bed1VacantSolvedLatch = false;

    Blynk.virtualWrite(
      V_BED1_ADMISSION,
      0
    );

    refreshAlerts();
  }
}

// =====================================================
// BED 2 ADMISSION
// V32
// =====================================================

BLYNK_WRITE(V_BED2_ADMISSION)
{
  int value =
    param.asInt();

  if (value == 1)
  {
    bed2Admitted = true;

    bed2IVSolvedLatch = false;
    bed2VacantSolvedLatch = false;

    // Keep admission ON
    Blynk.virtualWrite(
      V_BED2_ADMISSION,
      1
    );

    // Start Bed 2 demo
    processBed2Alerts();

    refreshAlerts();
  }
  else
  {
    bed2Admitted = false;

    removeAllBedAlerts(2);

    bed2IVSolvedLatch = false;
    bed2VacantSolvedLatch = false;

    Blynk.virtualWrite(
      V_BED2_ADMISSION,
      0
    );

    // Clear Bed 2 dashboard
    Blynk.virtualWrite(
      V_BED2_IV,
      0
    );

    Blynk.virtualWrite(
      V_BED2_FLOW,
      0
    );

    Blynk.virtualWrite(
      V_BED2_REMAINING,
      0
    );

    Blynk.virtualWrite(
      V_BED2_ETA,
      ""
    );

    Blynk.virtualWrite(
      V_BED2_STATUS,
      "NOT ADMITTED"
    );

    refreshAlerts();
  }
}

// =====================================================
// BED 1 NURSE ASSISTED EXIT
// V30
//
// ON = NURSE ASSISTED EXIT
// OFF = NORMAL
//
// It does NOT automatically return to OFF.
// =====================================================

BLYNK_WRITE(V_BED1_ASSISTED_EXIT)
{
  int value =
    param.asInt();

  if (value == 1)
  {
    // ---------------------------------------------
    // Nurse Assisted Exit ON
    // ---------------------------------------------

    bed1NurseAssisted = true;

    // Immediately remove BED EXIT
    removeAlert(
      1,
      ALERT_BED_VACANT
    );

    // Keep switch ON
    Blynk.virtualWrite(
      V_BED1_ASSISTED_EXIT,
      1
    );
  }
  else
  {
    // ---------------------------------------------
    // Nurse Assisted Exit OFF
    // ---------------------------------------------

    bed1NurseAssisted = false;

    Blynk.virtualWrite(
      V_BED1_ASSISTED_EXIT,
      0
    );

    // Once normal mode is restored,
    // a real vacant bed can generate BED EXIT.
    if (bed1Admitted &&
        bed1ReadingReceived &&
        bed1Status == "BED_VACANT")
    {
      bed1VacantSolvedLatch = false;

      addAlert(
        1,
        ALERT_BED_VACANT
      );
    }
  }

  refreshAlerts();
}

// =====================================================
// BED 2 NURSE ASSISTED EXIT
// V31
// =====================================================

BLYNK_WRITE(V_BED2_ASSISTED_EXIT)
{
  int value =
    param.asInt();

  if (value == 1)
  {
    bed2NurseAssisted = true;

    removeAlert(
      2,
      ALERT_BED_VACANT
    );

    // Keep switch ON
    Blynk.virtualWrite(
      V_BED2_ASSISTED_EXIT,
      1
    );
  }
  else
  {
    bed2NurseAssisted = false;

    Blynk.virtualWrite(
      V_BED2_ASSISTED_EXIT,
      0
    );

    if (bed2Admitted &&
        bed2Status == "BED_VACANT")
    {
      bed2VacantSolvedLatch = false;

      addAlert(
        2,
        ALERT_BED_VACANT
      );
    }
  }

  refreshAlerts();
}

// =====================================================
// ACKNOWLEDGE ALERT 1
// =====================================================

BLYNK_WRITE(V_ACK1)
{
  if (param.asInt() == 1)
  {
    acknowledgeAlertSlot(0);

    Blynk.virtualWrite(
      V_ACK1,
      0
    );
  }
}

// =====================================================
// SOLVE ALERT 1
// =====================================================

BLYNK_WRITE(V_SOLVE1)
{
  if (param.asInt() == 1)
  {
    solveAlertSlot(0);

    Blynk.virtualWrite(
      V_SOLVE1,
      0
    );
  }
}

// =====================================================
// ACKNOWLEDGE ALERT 2
// =====================================================

BLYNK_WRITE(V_ACK2)
{
  if (param.asInt() == 1)
  {
    acknowledgeAlertSlot(1);

    Blynk.virtualWrite(
      V_ACK2,
      0
    );
  }
}

// =====================================================
// SOLVE ALERT 2
// =====================================================

BLYNK_WRITE(V_SOLVE2)
{
  if (param.asInt() == 1)
  {
    solveAlertSlot(1);

    Blynk.virtualWrite(
      V_SOLVE2,
      0
    );
  }
}

// =====================================================
// ACKNOWLEDGE ALERT 3
// =====================================================

BLYNK_WRITE(V_ACK3)
{
  if (param.asInt() == 1)
  {
    acknowledgeAlertSlot(2);

    Blynk.virtualWrite(
      V_ACK3,
      0
    );
  }
}

// =====================================================
// SOLVE ALERT 3
// =====================================================

BLYNK_WRITE(V_SOLVE3)
{
  if (param.asInt() == 1)
  {
    solveAlertSlot(2);

    Blynk.virtualWrite(
      V_SOLVE3,
      0
    );
  }
}

// =====================================================
// ACKNOWLEDGE ALERT 4
// =====================================================

BLYNK_WRITE(V_ACK4)
{
  if (param.asInt() == 1)
  {
    acknowledgeAlertSlot(3);

    Blynk.virtualWrite(
      V_ACK4,
      0
    );
  }
}

// =====================================================
// SOLVE ALERT 4
// =====================================================

BLYNK_WRITE(V_SOLVE4)
{
  if (param.asInt() == 1)
  {
    solveAlertSlot(3);

    Blynk.virtualWrite(
      V_SOLVE4,
      0
    );
  }
}

// =====================================================
// BLYNK CONNECTED
// =====================================================

BLYNK_CONNECTED()
{
  Blynk.syncVirtual(
    V_BED1_ADMISSION,
    V_BED2_ADMISSION,
    V_BED1_ASSISTED_EXIT,
    V_BED2_ASSISTED_EXIT
  );

  clearAllAlertWidgets();
}

// =====================================================
// SETUP
// =====================================================

void setup()
{
  Serial.begin(115200);

  // STM32 UART
  STM32Serial.begin(
    115200,
    SERIAL_8N1,
    RXD2,
    TXD2
  );

  // =============================================
  // Initialize alert array
  // =============================================

  for (int i = 0; i < MAX_ALERTS; i++)
  {
    alerts[i].active = false;
    alerts[i].bed = 0;
    alerts[i].type = ALERT_NONE;
    alerts[i].createdTime = 0;
    alerts[i].acknowledged = false;
  }

  // =============================================
  // Initial states
  // =============================================

  bed1Admitted = false;
  bed2Admitted = false;

  bed1NurseAssisted = false;
  bed2NurseAssisted = false;

  bed1WaitForNewReading = false;

  // =============================================
  // Connect Blynk
  // =============================================

  Blynk.begin(
    BLYNK_AUTH_TOKEN,
    ssid,
    pass
  );

  // =============================================
  // Start with all alert sections hidden
  // =============================================

  clearAllAlertWidgets();

  // =============================================
  // Admission OFF
  // =============================================

  Blynk.virtualWrite(
    V_BED1_ADMISSION,
    0
  );

  Blynk.virtualWrite(
    V_BED2_ADMISSION,
    0
  );

  // =============================================
  // Nurse Assisted OFF
  // =============================================

  Blynk.virtualWrite(
    V_BED1_ASSISTED_EXIT,
    0
  );

  Blynk.virtualWrite(
    V_BED2_ASSISTED_EXIT,
    0
  );

  // =============================================
  // Bed 2 initial state
  // =============================================

  Blynk.virtualWrite(
    V_BED2_STATUS,
    "NOT ADMITTED"
  );
}

// =====================================================
// LOOP
// =====================================================

void loop()
{
  Blynk.run();

  // Continuously read STM32
  readSTM32();

  // =============================================
  // Bed 2 demo
  // =============================================

  if (bed2Admitted)
  {
    processBed2Alerts();
  }
}